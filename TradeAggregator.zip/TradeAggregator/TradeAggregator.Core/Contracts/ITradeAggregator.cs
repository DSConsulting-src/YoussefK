﻿using System.Collections.Generic;
using TradeAggregator.Model;

namespace TradeAggregator.Core.Contracts
{
    public interface ITradeAggregator
    {
        IEnumerable<TradeGroup> Aggregate(IEnumerable<Trade> tradeGroups);
    }
}