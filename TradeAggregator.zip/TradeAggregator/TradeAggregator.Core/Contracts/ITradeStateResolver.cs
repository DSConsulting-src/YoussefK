﻿using TradeAggregator.Model;
using TradeAggregator.Model.Enum;

namespace TradeAggregator.Core.Contracts
{
    public interface ITradeStateResolver
    {
        TradeGroupState Resolve(TradeGroup tradeGroup);
    }
}