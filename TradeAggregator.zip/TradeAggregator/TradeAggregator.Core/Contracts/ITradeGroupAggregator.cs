﻿using System.Collections.Generic;
using TradeAggregator.Model;

namespace TradeAggregator.Core.Contracts
{
    public interface ITradeGroupAggregator
    {
        IEnumerable<TradeGroup> Aggregate(string inputUri);
    }
}