﻿using System;
using System.Collections.Generic;
using System.Linq;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Logger;
using TradeAggregator.Model;
using TradeAggregator.Reader.Contracts;

namespace TradeAggregator.Core.Services
{
    public class TradeGroupAggregator : ITradeGroupAggregator
    {
        private readonly Dictionary<string, TradeGroup> _tradeGroups = new Dictionary<string, TradeGroup>();
        private readonly ILogger _logger;
        private readonly ITradeReader _tradeReader;
        private readonly ITradeStateResolver _stateResolver;

        public TradeGroupAggregator(ILoggerFactory loggerFactory, ITradeReader tradeReader, ITradeStateResolver resolver)
        {
            _logger = loggerFactory.CreateLogger<TradeGroupAggregator>();
            _tradeReader = tradeReader;
            _stateResolver = resolver;
        }

        public IEnumerable<TradeGroup> Aggregate(string inputUri)
        {
            try
            {
                foreach (var trade in _tradeReader.Read(inputUri))
                {
                    AggregateTrade(trade);
                }

                if (_tradeGroups.Any() && _tradeGroups.Values.Any())
                {
                    return _tradeGroups.Select(i => ApplyState(i.Value)).OrderBy(i => i.CorrelationID);
                }
            }
            catch (Exception e)
            {
                _logger.Error("Aggregate failed.", e);
            }

            return Enumerable.Empty<TradeGroup>();
        }

        private void AggregateTrade(Trade trade)
        {
            if (!_tradeGroups.ContainsKey(trade.CorrelationId))
            {
                _tradeGroups.Add(trade.CorrelationId, new TradeGroup(trade));
            }
            else
            {
                _tradeGroups[trade.CorrelationId].Value += trade.Value;
                _tradeGroups[trade.CorrelationId].Count++;
            }
        }

        private TradeGroup ApplyState(TradeGroup tradeGroup)
        {
            tradeGroup.State = _stateResolver.Resolve(tradeGroup);

            return tradeGroup;
        }
    }
}
