﻿namespace TradeAggregator.Console
{
    using System;
    using Unity;
    using Core.Contracts;
    using Core.Services;
    using Core.Proxy;
    using Logger;
    using Logger.Serilog;
    using Writer.Contracts;
    using Reader.Contracts;
    using Reader.Services;
    using Writer.Services;
    using Common;

    public static class Program
    {
        private const string DefaultInputUri = "Input.xml";
        private static UnityContainer _container;

        static void Main(string[] args)
        {
            try
            {
                _container = new UnityContainer();

                _container.RegisterSingleton<ILoggerFactory, SerilogLoggerFactory>();
                _container.RegisterSingleton<ITradeReader, TradeXmlReader>();
                _container.RegisterSingleton<ITradeAggregator, TradeAggregator>();
                _container.RegisterSingleton<ITradeWriter, TradeCsvWriter>();
                _container.RegisterSingleton<ITradeStateResolver, TradeStateResolver>();
                _container.RegisterSingleton<ITradeGroupAggregator, TradeGroupAggregator>();
                _container.RegisterSingleton<ITradeAggregatorProxy, TradeAggregatorProxy>();

                var proxy = _container.Resolve<ITradeAggregatorProxy>();

                var inputUri = GetInputUri();

                proxy.Aggregate(inputUri);
                //proxy.AnotherAggregate(inputUri);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                _container.Dispose();
            }
        }

        private static string GetInputUri()
        {
            var inputUri = DefaultInputUri;

            if (!string.IsNullOrEmpty(AggregatorConfiguration.Current.InputUri))
            {
                inputUri = AggregatorConfiguration.Current.InputUri;
            }

            return inputUri;
        }
    }
}
