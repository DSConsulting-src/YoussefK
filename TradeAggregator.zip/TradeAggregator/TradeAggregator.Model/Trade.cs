﻿using System.Xml.Serialization;

namespace TradeAggregator.Model
{
    [XmlRoot(ElementName = "Trade")]
    public class Trade
    {
        [XmlAttribute("CorrelationID")]
        public string CorrelationId { get; set; }

        [XmlAttribute("TradeID")]
        public string TradeId { get; set; }

        [XmlAttribute("NumberOfTrades")]
        public int NumberOfTrades { get; set; }

        [XmlAttribute("Limit")]
        public int Limit { get; set; }

        [XmlText]
        public int Value { get; set; }

        public override string ToString()
        {
            return $"Trade [CorrelationId={CorrelationId} | NumberOfTrades={NumberOfTrades} | Limit={Limit} | Value={Value} | TradeId={TradeId}";
        }

    }
}
