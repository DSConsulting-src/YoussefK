﻿namespace TradeAggregator.Model.Enum
{
    public enum TradeGroupState
    {
        Accepted,
        Pending,
        Rejected,
    }
}
