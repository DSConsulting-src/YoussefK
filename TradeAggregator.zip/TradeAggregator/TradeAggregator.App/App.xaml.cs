﻿
namespace TradeAggregator.App
{
    using System.Windows;
    using Applications.Controllers;
    using System;
    using System.Waf.Applications;
    using System.Windows.Threading;
    using Applications.ViewModels;
    using Applications.Views;
    using Presentation.Views;
    using Unity;
    using Core.Contracts;
    using Core.Proxy;
    using Core.Services;
    using Logger;
    using Logger.Serilog;
    using Reader.Contracts;
    using Reader.Services;
    using Writer.Contracts;
    using Writer.Services;

    public partial class App : Application
    {
        private UnityContainer _container;
        private ApplicationController _controller;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            ShutdownMode = ShutdownMode.OnMainWindowClose;

            AppDomain.CurrentDomain.UnhandledException += AppDomainUnhandledException;
            DispatcherUnhandledException += AppDispatcherUnhandledException;

            Configure();

            Start();
        }
        
        protected override void OnExit(ExitEventArgs e)
        {
            _controller.Shutdown();
            _container.Dispose();

            base.OnExit(e);
        }


        private void Configure()
        {
            _container = new UnityContainer();

            _container.RegisterSingleton<ILoggerFactory, SerilogLoggerFactory>();
            _container.RegisterSingleton<ITradeReader, TradeXmlReader>();
            _container.RegisterSingleton<ITradeAggregator, TradeAggregator>();
            _container.RegisterSingleton<ITradeWriter, TradeCsvWriter>();
            _container.RegisterSingleton<ITradeStateResolver, TradeStateResolver>();
            _container.RegisterSingleton<ITradeGroupAggregator, TradeGroupAggregator>();
            _container.RegisterSingleton<ITradeAggregatorProxy, TradeAggregatorProxy>();

            _container.RegisterSingleton<IAggregatorView, AggregatorView>();
            _container.RegisterSingleton<AggregatorViewModel>();

            _container.RegisterSingleton<ILogView, LogView>();
            _container.RegisterSingleton<LogViewModel>();

            _container.RegisterSingleton<IShellView, ShellWindow>();
            _container.RegisterSingleton<ShellViewModel>();

            _container.RegisterSingleton<ApplicationController>();
        }

        private void Start()
        {
            _controller = _container.Resolve<ApplicationController>();

            _controller.Initialize();
            _controller.Run();
        }

        private void AppDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            HandleException(e.Exception, false);
        }

        private static void AppDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            HandleException(e.ExceptionObject as Exception, e.IsTerminating);
        }

        private static void HandleException(Exception e, bool isTerminating)
        {
            if (e == null) return;

            if (!isTerminating)
            {
                MessageBox.Show($"Unknown error: {e}", ApplicationInfo.ProductName, MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
