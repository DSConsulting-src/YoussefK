﻿using System.Waf.Applications;

namespace TradeAggregator.App.Applications.Views
{
    internal interface IShellView : IView
    {
        void Show();

        void Close();
    }
}
