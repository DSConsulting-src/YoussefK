﻿namespace TradeAggregator.App.Applications.ViewModels
{
    using System.Waf.Applications;
    using Views;

    internal class ShellViewModel : ViewModel<IShellView>
    {
        public ShellViewModel(IShellView view, AggregatorViewModel aggregatorViewModel, LogViewModel logViewModel)
            : base(view)
        {
            LogViewModel = logViewModel;
            AggregatorViewModel = aggregatorViewModel;
            ExitCommand = new DelegateCommand(Close);
        }

        public string Title => ApplicationInfo.ProductName;

        public DelegateCommand ExitCommand { get; }

        public AggregatorViewModel AggregatorViewModel { get; }

        public LogViewModel LogViewModel { get; }

        public void Show()
        {
            ViewCore.Show();
        }

        private void Close()
        {
            ViewCore.Close();
        }
    }
}
