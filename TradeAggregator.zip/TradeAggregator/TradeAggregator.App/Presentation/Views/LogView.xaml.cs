﻿using System.Windows.Controls;
using TradeAggregator.App.Applications.Views;

namespace TradeAggregator.App.Presentation.Views
{
    public partial class LogView : UserControl, ILogView
    {
        public LogView()
        {
            InitializeComponent();
        }
    }
}
