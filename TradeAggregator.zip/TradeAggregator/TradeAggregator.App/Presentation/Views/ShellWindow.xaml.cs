﻿using MahApps.Metro.Controls;
using TradeAggregator.App.Applications.Views;

namespace TradeAggregator.App.Presentation.Views
{
    public partial class ShellWindow : MetroWindow, IShellView
    {
        public ShellWindow()
        {
            InitializeComponent();
        }
        private void HamburgerMenuControlItemClick(object sender, ItemClickEventArgs e)
        {
            HamburgerMenuControl.Content = e.ClickedItem;
            HamburgerMenuControl.IsPaneOpen = false;
        }
    }
}
