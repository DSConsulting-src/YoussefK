﻿using System.Collections.Generic;
using TradeAggregator.Model;

namespace TradeAggregator.Serializer
{
    public interface ITradeParser
    {
        List<Trade> Parse(string fileName);
    }
}