﻿namespace TradeAggregator.Writer.Services
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using System.IO;
    using CsvHelper;
    using Logger;
    using Model;
    using Contracts;
    using Common;

    public class TradeCsvWriter : ITradeWriter
    {
        private const string DefaultResultUri = "result.csv";
        private const string DefaultDelimiter = ",";

        private readonly ILogger _logger;

        public TradeCsvWriter(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<TradeCsvWriter>();
        }

        public void Write(IEnumerable<TradeGroup> tradeGroups)
        {
            if (tradeGroups == null) 
                throw new ArgumentNullException(nameof(tradeGroups));

            try
            {
                var resultUri = GetResultUri();

                _logger.Info($"Write {resultUri}...");

                using (var writer = new StreamWriter(resultUri))
                using (var csvWriter = new CsvWriter(writer))
                {
                    csvWriter.Configuration.Delimiter = DefaultDelimiter;

                    csvWriter.WriteField(nameof(TradeGroup.CorrelationID));
                    csvWriter.WriteField(nameof(TradeGroup.NumberOfTrades));
                    csvWriter.WriteField(nameof(TradeGroup.State));
                    csvWriter.NextRecord();

                    foreach (var tradeGroup in tradeGroups.OrderBy(x => x.CorrelationID))
                    {
                        csvWriter.WriteField(tradeGroup.CorrelationID);
                        csvWriter.WriteField(tradeGroup.NumberOfTrades);
                        csvWriter.WriteField(tradeGroup.State);
                        csvWriter.NextRecord();
                    }
                }

                _logger.Info("Write finished.");
            }
            catch (Exception e)
            {
                _logger.Error("Write failed.", e);
            }
        }

        private static string GetResultUri()
        {
            var resultUri = DefaultResultUri;

            if (!string.IsNullOrEmpty(AggregatorConfiguration.Current.ResultUri))
            {
                resultUri = AggregatorConfiguration.Current.ResultUri;
            }

            return resultUri;
        }
    }
}
