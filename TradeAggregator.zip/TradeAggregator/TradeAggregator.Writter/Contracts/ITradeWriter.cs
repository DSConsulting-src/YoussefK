﻿using System.Collections.Generic;
using TradeAggregator.Model;

namespace TradeAggregator.Writer.Contracts
{
    public interface ITradeWriter
    {
        void Write(IEnumerable<TradeGroup> tradeGroups);
    }
}