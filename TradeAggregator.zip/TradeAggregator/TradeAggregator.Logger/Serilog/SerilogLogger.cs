﻿
using System;

namespace TradeAggregator.Logger.Serilog
{
    public class SerilogLogger : ILogger
    {
        private readonly global::Serilog.ILogger _logger;

        public SerilogLogger(global::Serilog.ILogger logger, string name)
        {
            _logger = logger.ForContext("LoggerName", name);
        }

        public void Debug(string message)
        {
            _logger.Debug(message);
        }

        public void Info(string message)
        {
            _logger.Information(message);
        }

        public void Warn(string message)
        {
            _logger.Warning(message);
        }

        public void Error(string message)
        {
            _logger.Error(message);
        }

        public void Error(string message, Exception exception)
        {
            _logger.Error(exception, message);
        }

        public void Fatal(string message)
        {
            _logger.Fatal(message);
        }

        public void Fatal(string message, Exception exception)
        {
            _logger.Fatal(exception, message);
        }
    }

    public class SerilogLogger<T> : SerilogLogger, ILogger<T>
    {
        public SerilogLogger(global::Serilog.ILogger logger)
            : base(logger, typeof(T).Name)
        {
        }
    }
}
