﻿using System.Collections.Generic;
using TradeAggregator.Model;

namespace TradeAggregator.Reader.Contracts
{
    public interface ITradeReader
    {
        IList<Trade> ReadAll(string inputUri);

        IEnumerable<Trade> Read(string inputUri);
    }
}